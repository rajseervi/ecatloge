"use client";

import { type ChangeEvent, useRef, type ReactNode } from "react";
import Link from "next/link";

/* ------------------------------------------------------------------ */
/*  Types                                                             */
/* ------------------------------------------------------------------ */

export interface CatalogHeaderConfig {
  companyName: string;
  companyTagline: string;
  totalProducts: number;
  categories: string[];
  activeCategory: string;
  searchTerm: string;
  isSearching: boolean;
  isScrolled: boolean;
  isHeaderVisible: boolean;
  isCompact: boolean;
  scrollProgress: number;
  systemHealth: "healthy" | "warning" | "critical";
  apiResponseTime: number;
  activeUsers: number;
  notificationCount: number;
  // Dropdown toggles (lifted up so parent controls them)
  showNotifications: boolean;
  showUserMenu: boolean;
  showQuickActions: boolean;
}

interface CatalogHeaderProps {
  config: CatalogHeaderConfig;
  onSearchChange: (value: string) => void;
  onClearSearch: () => void;
  onCategorySelect: (category: string) => void;
  onToggleNotifications: () => void;
  onToggleUserMenu: () => void;
  onToggleQuickActions: () => void;
  onShowHeader: () => void;
  /** Render something inside the "Admin" avatar dropdown */
  userMenuExtra?: ReactNode;
  /** Override for the header left icon (defaults to first letter of company name) */
  logo?: ReactNode;
}

/* ------------------------------------------------------------------ */
/*  Sub-components                                                     */
/* ------------------------------------------------------------------ */

function ScrollProgressBar({ progress }: { progress: number }) {
  return (
    <div className="absolute top-0 left-0 right-0 h-1 bg-gray-200/50 overflow-hidden">
      <div
        className="h-full bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 transition-all duration-150 ease-out shadow-lg shadow-indigo-500/50"
        style={{ width: `${progress}%` }}
      >
        <div className="absolute inset-0 bg-gradient-to-r from-transparent via-white/30 to-transparent animate-[shimmer_2s_infinite]" />
      </div>
    </div>
  );
}

function TopBar() {
  return (
    <div className="border-b border-gray-100 bg-gradient-to-r from-indigo-50/50 via-purple-50/50 to-pink-50/50">
      <div className="px-4 md:px-6 lg:px-8 py-2">
        <div className="flex items-center justify-between text-xs">
          <div className="flex items-center gap-4">
            <span className="flex items-center gap-1.5 text-gray-600">
              <svg
                className="w-3.5 h-3.5 text-green-500 animate-pulse"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                  clipRule="evenodd"
                />
              </svg>
              <span className="font-medium">All systems operational</span>
            </span>
            <span className="hidden sm:flex items-center gap-1.5 text-gray-500">
              <svg
                className="w-3.5 h-3.5"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path
                  fillRule="evenodd"
                  d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z"
                  clipRule="evenodd"
                />
              </svg>
              Last updated: {new Date().toLocaleTimeString()}
            </span>
          </div>
          <div className="flex items-center gap-3">
            <button className="flex items-center gap-1.5 text-gray-600 hover:text-indigo-600 transition-colors group">
              <svg
                className="w-3.5 h-3.5 group-hover:scale-110 transition-transform"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
              </svg>
              <span className="hidden md:inline">Contact Support</span>
            </button>
            <button className="flex items-center gap-1.5 text-gray-600 hover:text-indigo-600 transition-colors group">
              <svg
                className="w-3.5 h-3.5 group-hover:scale-110 transition-transform"
                fill="currentColor"
                viewBox="0 0 20 20"
              >
                <path
                  fillRule="evenodd"
                  d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                  clipRule="evenodd"
                />
              </svg>
              <span className="hidden md:inline">Help</span>
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

function NotificationsPanel({
  count,
  onClose,
}: {
  count: number;
  onClose: () => void;
}) {
  const notifications = [
    { id: 1, type: "success" as const, message: "New products added successfully", time: "2 min ago" },
    { id: 2, type: "info" as const, message: "System backup completed", time: "15 min ago" },
    { id: 3, type: "warning" as const, message: "Low stock alert for 3 items", time: "1 hour ago" },
  ];

  const iconMap = {
    success: (
      <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
        <path fillRule="evenodd" d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z" clipRule="evenodd" />
      </svg>
    ),
    warning: (
      <svg className="w-5 h-5 text-yellow-600" fill="currentColor" viewBox="0 0 20 20">
        <path fillRule="evenodd" d="M8.257 3.099c.765-1.36 2.722-1.36 3.486 0l5.58 9.92c.75 1.334-.213 2.98-1.742 2.98H4.42c-1.53 0-2.493-1.646-1.743-2.98l5.58-9.92zM11 13a1 1 0 11-2 0 1 1 0 012 0zm-1-8a1 1 0 00-1 1v3a1 1 0 002 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
      </svg>
    ),
    info: (
      <svg className="w-5 h-5 text-blue-600" fill="currentColor" viewBox="0 0 20 20">
        <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z" clipRule="evenodd" />
      </svg>
    ),
  };

  const badgeMap = {
    success: "bg-green-100",
    warning: "bg-yellow-100",
    info: "bg-blue-100",
  };

  return (
    <div className="absolute right-0 mt-3 w-80 sm:w-96 bg-white rounded-2xl shadow-2xl border-2 border-gray-200 z-50 animate-fadeIn max-h-[500px] overflow-hidden">
      <div className="px-5 py-4 border-b border-gray-100 sticky top-0 bg-gradient-to-r from-indigo-50 to-purple-50">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <h3 className="text-base font-bold text-gray-900">Notifications</h3>
            {count > 0 && (
              <span className="px-2 py-0.5 bg-indigo-600 text-white text-xs font-bold rounded-full">
                {count}
              </span>
            )}
          </div>
          <span className="text-xs text-gray-500 font-mono bg-white px-2 py-1 rounded border border-gray-200">
            ⌘N
          </span>
        </div>
      </div>
      {notifications.length > 0 ? (
        <div className="divide-y divide-gray-100 max-h-[350px] overflow-y-auto">
          {notifications.map((n) => (
            <div
              key={n.id}
              className="px-5 py-4 hover:bg-gradient-to-r hover:from-gray-50 hover:to-indigo-50 transition-all duration-200 cursor-pointer group"
            >
              <div className="flex items-start gap-3">
                <div
                  className={`w-10 h-10 rounded-xl flex items-center justify-center flex-shrink-0 group-hover:scale-110 transition-transform ${badgeMap[n.type]}`}
                >
                  {iconMap[n.type]}
                </div>
                <div className="flex-1 min-w-0">
                  <p className="text-sm font-medium text-gray-900 group-hover:text-indigo-900">
                    {n.message}
                  </p>
                  <p className="text-xs text-gray-500 mt-1 flex items-center gap-1">
                    <svg
                      className="w-3 h-3"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z"
                        clipRule="evenodd"
                      />
                    </svg>
                    {n.time}
                  </p>
                </div>
              </div>
            </div>
          ))}
        </div>
      ) : (
        <div className="px-5 py-12 text-center">
          <div className="w-16 h-16 bg-gray-100 rounded-full flex items-center justify-center mx-auto mb-3">
            <svg
              className="w-8 h-8 text-gray-400"
              fill="none"
              viewBox="0 0 24 24"
              stroke="currentColor"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
              />
            </svg>
          </div>
          <p className="text-sm font-medium text-gray-900">All caught up!</p>
          <p className="text-xs text-gray-500 mt-1">No new notifications</p>
        </div>
      )}
      <div className="px-5 py-3 border-t border-gray-100 bg-gray-50 flex items-center justify-between">
        <button className="text-xs text-indigo-600 hover:text-indigo-700 font-semibold hover:underline transition-colors">
          Mark all as read
        </button>
        <button className="text-xs text-gray-600 hover:text-gray-700 font-medium hover:underline transition-colors">
          View all
        </button>
      </div>
    </div>
  );
}

function QuickActionsPanel({ onClose }: { onClose: () => void }) {
  const actions = [
    {
      label: "Export Data",
      icon: (
        <svg className="w-5 h-5 text-indigo-600" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M3 17a1 1 0 011-1h12a1 1 0 110 2H4a1 1 0 01-1-1zm3.293-7.707a1 1 0 011.414 0L9 10.586V3a1 1 0 112 0v7.586l1.293-1.293a1 1 0 111.414 1.414l-3 3a1 1 0 01-1.414 0l-3-3a1 1 0 010-1.414z" clipRule="evenodd" />
        </svg>
      ),
      hover: "hover:bg-indigo-50",
    },
    {
      label: "Add Product",
      icon: (
        <svg className="w-5 h-5 text-green-600" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M10 3a1 1 0 011 1v5h5a1 1 0 110 2h-5v5a1 1 0 11-2 0v-5H4a1 1 0 110-2h5V4a1 1 0 011-1z" clipRule="evenodd" />
        </svg>
      ),
      hover: "hover:bg-green-50",
    },
    {
      label: "Analytics",
      icon: (
        <svg className="w-5 h-5 text-purple-600" fill="currentColor" viewBox="0 0 20 20">
          <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
        </svg>
      ),
      hover: "hover:bg-purple-50",
    },
    {
      label: "Settings",
      icon: (
        <svg className="w-5 h-5 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
          <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
        </svg>
      ),
      hover: "hover:bg-gray-50",
    },
  ];

  return (
    <div className="absolute right-0 mt-2 w-48 sm:w-56 bg-white rounded-xl shadow-2xl border border-gray-200 py-2 z-50 animate-fadeIn">
      <div className="px-4 py-2 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <h3 className="text-sm font-bold text-gray-900">Quick Actions</h3>
          <span className="text-xs text-gray-500">⌘Q</span>
        </div>
      </div>
      {actions.map((a) => (
        <button
          key={a.label}
          className={`w-full px-4 py-2.5 text-sm text-gray-700 ${a.hover} transition-colors flex items-center gap-3 text-left group`}
        >
          <span className="group-hover:scale-110 transition-transform">{a.icon}</span>
          <span>{a.label}</span>
        </button>
      ))}
    </div>
  );
}

function UserMenuPanel({
  onClose,
  extra,
}: {
  onClose: () => void;
  extra?: ReactNode;
}) {
  return (
    <div className="absolute right-0 mt-3 w-64 sm:w-72 bg-white rounded-2xl shadow-2xl border-2 border-gray-200 py-2 z-50 animate-fadeIn overflow-hidden">
      <div className="px-5 py-4 border-b border-gray-100 bg-gradient-to-br from-indigo-50 to-purple-50">
        <div className="flex items-center gap-3">
          <div className="w-12 h-12 rounded-full bg-gradient-to-br from-indigo-600 to-purple-600 flex items-center justify-center font-bold text-white text-lg ring-4 ring-indigo-100">
            A
          </div>
          <div className="flex-1">
            <p className="text-sm font-bold text-gray-900">Administrator</p>
            <p className="text-xs text-gray-600 mt-0.5">admin@company.com</p>
          </div>
        </div>
      </div>
      <div className="py-2">
        <Link
          href="/admin"
          className="flex items-center gap-3 px-5 py-3 text-sm text-gray-700 hover:bg-gradient-to-r hover:from-indigo-50 hover:to-purple-50 transition-all duration-200 group"
        >
          <div className="w-9 h-9 rounded-lg bg-indigo-100 flex items-center justify-center group-hover:scale-110 transition-transform">
            <svg className="w-5 h-5 text-indigo-600" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M11.49 3.17c-.38-1.56-2.6-1.56-2.98 0a1.532 1.532 0 01-2.286.948c-1.372-.836-2.942.734-2.106 2.106.54.886.061 2.042-.947 2.287-1.561.379-1.561 2.6 0 2.978a1.532 1.532 0 01.947 2.287c-.836 1.372.734 2.942 2.106 2.106a1.532 1.532 0 012.287.947c.379 1.561 2.6 1.561 2.978 0a1.533 1.533 0 012.287-.947c1.372.836 2.942-.734 2.106-2.106a1.533 1.533 0 01.947-2.287c1.561-.379 1.561-2.6 0-2.978a1.532 1.532 0 01-.947-2.287c.836-1.372-.734-2.942-2.106-2.106a1.532 1.532 0 01-2.287-.947zM10 13a3 3 0 100-6 3 3 0 000 6z" clipRule="evenodd" />
            </svg>
          </div>
          <span className="font-medium">Admin Panel</span>
        </Link>
        <button className="w-full flex items-center gap-3 px-5 py-3 text-sm text-gray-700 hover:bg-gradient-to-r hover:from-gray-50 hover:to-indigo-50 transition-all duration-200 text-left group">
          <div className="w-9 h-9 rounded-lg bg-gray-100 flex items-center justify-center group-hover:scale-110 transition-transform">
            <svg className="w-5 h-5 text-gray-600" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z" clipRule="evenodd" />
            </svg>
          </div>
          <span className="font-medium">Profile Settings</span>
        </button>
        {extra}
      </div>
      <div className="border-t border-gray-100 mt-2 pt-2">
        <button className="w-full flex items-center gap-3 px-5 py-3 text-sm text-red-600 hover:bg-gradient-to-r hover:from-red-50 hover:to-pink-50 transition-all duration-200 text-left group">
          <div className="w-9 h-9 rounded-lg bg-red-100 flex items-center justify-center group-hover:scale-110 transition-transform">
            <svg className="w-5 h-5 text-red-600" fill="currentColor" viewBox="0 0 20 20">
              <path fillRule="evenodd" d="M3 3a1 1 0 00-1 1v12a1 1 0 102 0V4a1 1 0 00-1-1zm10.293 9.293a1 1 0 001.414 1.414l3-3a1 1 0 000-1.414l-3-3a1 1 0 10-1.414 1.414L14.586 9H7a1 1 0 100 2h7.586l-1.293 1.293z" clipRule="evenodd" />
            </svg>
          </div>
          <span className="font-semibold">Sign Out</span>
        </button>
      </div>
    </div>
  );
}

/* ------------------------------------------------------------------ */
/*  Main header component                                             */
/* ------------------------------------------------------------------ */

export default function CatalogHeader({
  config,
  onSearchChange,
  onClearSearch,
  onCategorySelect,
  onToggleNotifications,
  onToggleUserMenu,
  onToggleQuickActions,
  onShowHeader,
  userMenuExtra,
  logo,
}: CatalogHeaderProps) {
  const searchInputRef = useRef<HTMLInputElement | null>(null);
  const {
    companyName,
    companyTagline,
    totalProducts,
    categories,
    activeCategory,
    searchTerm,
    isSearching,
    isScrolled,
    isHeaderVisible,
    isCompact,
    scrollProgress,
    systemHealth,
    apiResponseTime,
    activeUsers,
    notificationCount,
    showNotifications,
    showUserMenu,
    showQuickActions,
  } = config;

  const handleSearchChange = (e: ChangeEvent<HTMLInputElement>) => {
    onSearchChange(e.target.value);
  };

  return (
    <>
      <header
        className={`header-transition sticky top-0 z-50 bg-white/95 backdrop-blur-xl border-b border-gray-200/80 ${
          isScrolled ? "shadow-2xl" : "shadow-lg"
        } ${isHeaderVisible ? "translate-y-0" : "-translate-y-full"}`}
      >
        <ScrollProgressBar progress={scrollProgress} />

        {/* Top bar — hidden on compact */}
        <div
          className={`transition-all duration-300 overflow-hidden ${
            isCompact ? "max-h-0 opacity-0" : "max-h-20 opacity-100"
          }`}
        >
          <TopBar />
        </div>

        {/* Main header content */}
        <div className="relative">
          <div
            className="absolute inset-0 bg-gradient-to-r from-indigo-600/5 via-purple-500/5 to-rose-500/5 pointer-events-none"
            aria-hidden="true"
          />

          <div
            className={`px-3 sm:px-4 md:px-6 lg:px-8 relative transition-all duration-300 ${
              isCompact ? "py-2 sm:py-3" : "py-3 sm:py-4 md:py-5"
            }`}
          >
            {/* ────────────── MOBILE (< 768px) ────────────── */}
            <div className="md:hidden">
              {/* Top row */}
              <div className="flex items-center justify-between gap-3 mb-3">
                <div className="flex items-center gap-2">
                  <div className="relative">
                    <div className="w-10 h-10 rounded-xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 flex items-center justify-center text-white font-bold text-lg shadow-lg">
                      {logo ?? companyName.charAt(0)}
                    </div>
                  </div>
                  <div>
                    <h1 className="text-lg font-bold bg-gradient-to-r from-gray-900 via-indigo-900 to-purple-900 bg-clip-text text-transparent">
                      {companyName}
                    </h1>
                    <span className="inline-flex items-center gap-1 px-1.5 py-0.5 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 text-white text-[9px] font-medium">
                      <svg
                        className="w-2.5 h-2.5"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                          clipRule="evenodd"
                        />
                      </svg>
                      Verified
                    </span>
                  </div>
                </div>

                {/* Mobile actions */}
                <div className="flex items-center gap-2">
                  {/* Quick Actions */}
                  <div className="relative">
                    <button
                      onClick={onToggleQuickActions}
                      className="relative p-2 rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 text-white shadow-lg active:scale-95 transition-all"
                      title="Quick Actions"
                    >
                      <svg
                        className="w-5 h-5"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M13 10V3L4 14h7v7l9-11h-7z"
                        />
                      </svg>
                    </button>
                    {showQuickActions && (
                      <QuickActionsPanel onClose={onToggleQuickActions} />
                    )}
                  </div>

                  {/* Notifications */}
                  <div className="relative">
                    <button
                      onClick={onToggleNotifications}
                      className="relative p-2 rounded-xl bg-white border-2 border-gray-200 hover:border-indigo-400 shadow-md active:scale-95 transition-all"
                      title="Notifications"
                    >
                      <svg
                        className="w-5 h-5 text-gray-600"
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
                        />
                      </svg>
                      {notificationCount > 0 && (
                        <span className="absolute -top-1 -right-1 min-w-[18px] h-[18px] bg-gradient-to-r from-red-500 to-pink-500 rounded-full ring-2 ring-white flex items-center justify-center px-1">
                          <span className="text-white text-[10px] font-bold">
                            {notificationCount}
                          </span>
                        </span>
                      )}
                    </button>
                    {showNotifications && (
                      <NotificationsPanel
                        count={notificationCount}
                        onClose={onToggleNotifications}
                      />
                    )}
                  </div>

                  {/* User */}
                  <div className="relative">
                    <button
                      onClick={onToggleUserMenu}
                      className="p-2 rounded-xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 text-white shadow-lg active:scale-95 transition-all flex items-center gap-1.5"
                    >
                      <div className="w-6 h-6 rounded-full bg-white/20 backdrop-blur flex items-center justify-center font-bold text-xs ring-2 ring-white/30">
                        A
                      </div>
                      <svg
                        className="w-3.5 h-3.5"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </button>
                    {showUserMenu && (
                      <UserMenuPanel
                        onClose={onToggleUserMenu}
                        extra={userMenuExtra}
                      />
                    )}
                  </div>
                </div>
              </div>

              {/* Mobile search */}
              <div className="relative mb-2">
                <div className="absolute left-3 top-1/2 -translate-y-1/2 pointer-events-none">
                  <svg
                    className="w-5 h-5 text-gray-400"
                    fill="none"
                    viewBox="0 0 24 24"
                    stroke="currentColor"
                    strokeWidth="2"
                  >
                    <path
                      strokeLinecap="round"
                      strokeLinejoin="round"
                      d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                    />
                  </svg>
                </div>
                <input
                  ref={searchInputRef}
                  type="text"
                  value={searchTerm}
                  onChange={handleSearchChange}
                  placeholder="Search products..."
                  className="w-full pl-11 pr-10 py-3 rounded-xl border-2 border-gray-200 bg-white text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 shadow-md text-sm"
                />
                {searchTerm && (
                  <button
                    onClick={onClearSearch}
                    className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-red-500 transition-colors p-1"
                  >
                    <svg
                      className="w-5 h-5"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path
                        fillRule="evenodd"
                        d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </button>
                )}
              </div>

              {/* Mobile quick stats */}
              <div className="flex items-center gap-2 overflow-x-auto pb-1 scrollbar-hide">
                <div className="flex items-center gap-2 bg-gradient-to-br from-indigo-50 to-purple-50 border-2 border-indigo-200/50 rounded-xl px-3 py-2 shadow-md flex-shrink-0">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-indigo-500 to-purple-600 flex items-center justify-center shadow-lg">
                    <svg
                      className="w-4 h-4 text-white"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
                    </svg>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[9px] font-semibold text-gray-500 uppercase tracking-wider">
                      Products
                    </span>
                    <span className="text-base font-extrabold bg-gradient-to-r from-indigo-600 to-purple-600 bg-clip-text text-transparent">
                      {totalProducts.toLocaleString()}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 bg-gradient-to-br from-pink-50 to-rose-50 border-2 border-pink-200/50 rounded-xl px-3 py-2 shadow-md flex-shrink-0">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-pink-500 to-orange-500 flex items-center justify-center shadow-lg">
                    <svg
                      className="w-4 h-4 text-white"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path
                        fillRule="evenodd"
                        d="M2 5a2 2 0 012-2h12a2 2 0 012 2v10a2 2 0 01-2 2H4a2 2 0 01-2-2V5zm3.293 1.293a1 1 0 011.414 0l3 3a1 1 0 010 1.414l-3 3a1 1 0 01-1.414-1.414L7.586 10 5.293 7.707a1 1 0 010-1.414zM11 12a1 1 0 100 2h3a1 1 0 100-2h-3z"
                        clipRule="evenodd"
                      />
                    </svg>
                  </div>
                  <div className="flex flex-col">
                    <span className="text-[9px] font-semibold text-gray-500 uppercase tracking-wider">
                      Categories
                    </span>
                    <span className="text-base font-extrabold bg-gradient-to-r from-pink-600 to-orange-600 bg-clip-text text-transparent">
                      {categories.length - 1}
                    </span>
                  </div>
                </div>

                <div className="flex items-center gap-2 bg-gradient-to-br from-blue-50 to-indigo-50 border-2 border-blue-200/50 rounded-xl px-3 py-2 shadow-md flex-shrink-0">
                  <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-blue-500 to-indigo-600 flex items-center justify-center shadow-lg relative">
                    <svg
                      className="w-4 h-4 text-white"
                      fill="currentColor"
                      viewBox="0 0 20 20"
                    >
                      <path d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                    </svg>
                    <div className="absolute -top-0.5 -right-0.5 w-2 h-2 bg-green-500 rounded-full ring-2 ring-blue-50" />
                  </div>
                  
                </div>

                <div className="flex items-center gap-2 bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200/50 rounded-xl px-3 py-2 shadow-md flex-shrink-0">
                  <span className="relative flex h-3 w-3">
                    <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                    <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500 ring-2 ring-green-200" />
                  </span>
                  <div className="flex flex-col">
                    <span className="text-[9px] font-semibold text-gray-500 uppercase tracking-wider">
                      Status
                    </span>
                    <span className="text-xs font-bold text-green-700">Live</span>
                  </div>
                </div>
              </div>
            </div>

            {/* ────────────── TABLET & DESKTOP (≥ 768px) ────────────── */}
            <div className="hidden md:flex flex-col gap-3 sm:gap-4 overflow-visible">
              {/* Brand + Actions row */}
              <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 sm:gap-4 overflow-visible">
                {/* Brand */}
                <div className="flex items-center gap-2 sm:gap-3 md:gap-4">
                  <div className="relative group">
                    <div
                      className={`absolute -inset-1 bg-gradient-to-r from-indigo-600 to-purple-600 rounded-2xl blur opacity-25 group-hover:opacity-40 transition-all duration-300 ${
                        isCompact ? "opacity-0" : ""
                      }`}
                    />
                    <div
                      className={`relative rounded-xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 flex items-center justify-center text-white font-bold shadow-xl ring-4 ring-white/50 group-hover:scale-105 transition-all duration-300 ${
                        isCompact
                          ? "w-8 h-8 text-base sm:w-10 sm:h-10 sm:text-lg"
                          : "w-10 h-10 text-lg sm:w-12 sm:h-12 sm:text-xl md:w-14 md:h-14 md:text-2xl"
                      }`}
                    >
                      {logo ?? companyName.charAt(0)}
                    </div>
                  </div>
                  <div
                    className={`transition-all duration-300 ${
                      isCompact ? "space-y-0" : "space-y-0.5 sm:space-y-1"
                    }`}
                  >
                    <div className="flex items-center gap-1.5 sm:gap-2">
                      <h1
                        className={`font-bold bg-gradient-to-r from-gray-900 via-indigo-900 to-purple-900 bg-clip-text text-transparent transition-all duration-300 ${
                          isCompact
                            ? "text-base sm:text-lg md:text-xl"
                            : "text-lg sm:text-xl md:text-2xl lg:text-3xl"
                        }`}
                      >
                        {companyName}
                      </h1>
                      <span
                        className={`inline-flex items-center gap-1 px-1.5 py-0.5 sm:px-2 rounded-full bg-gradient-to-r from-indigo-500 to-purple-500 text-white font-medium shadow-sm transition-all duration-300 ${
                          isCompact
                            ? "text-[10px] scale-90"
                            : "text-[10px] sm:text-xs scale-90 sm:scale-100"
                        }`}
                      >
                        <svg
                          className="w-3 h-3"
                          fill="currentColor"
                          viewBox="0 0 20 20"
                        >
                          <path
                            fillRule="evenodd"
                            d="M6.267 3.455a3.066 3.066 0 001.745-.723 3.066 3.066 0 013.976 0 3.066 3.066 0 001.745.723 3.066 3.066 0 012.812 2.812c.051.643.304 1.254.723 1.745a3.066 3.066 0 010 3.976 3.066 3.066 0 00-.723 1.745 3.066 3.066 0 01-2.812 2.812 3.066 3.066 0 00-1.745.723 3.066 3.066 0 01-3.976 0 3.066 3.066 0 00-1.745-.723 3.066 3.066 0 01-2.812-2.812 3.066 3.066 0 00-.723-1.745 3.066 3.066 0 010-3.976 3.066 3.066 0 00.723-1.745 3.066 3.066 0 012.812-2.812zm7.44 5.252a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                            clipRule="evenodd"
                          />
                        </svg>
                        Verified
                      </span>
                    </div>
                    <p
                      className={`text-xs sm:text-sm text-gray-600 flex items-center gap-1.5 sm:gap-2 transition-all duration-300 overflow-hidden ${
                        isCompact
                          ? "max-h-0 opacity-0"
                          : "max-h-10 opacity-100 mt-0.5"
                      }`}
                    >
                      <span className="truncate">{companyTagline}</span>
                      <span className="hidden md:inline text-gray-400">•</span>
                      <span className="hidden md:inline text-indigo-600 font-medium whitespace-nowrap">
                        {totalProducts.toLocaleString()} products
                      </span>
                    </p>
                  </div>
                </div>

                {/* Controls */}
                <div className="flex items-center gap-1.5 sm:gap-2 md:gap-2.5 text-sm overflow-visible">
                  {/* Health */}
                   
                  

                  {/* Quick actions */}
                  <div className="relative">
                    <button
                      onClick={onToggleQuickActions}
                      className={`relative rounded-lg sm:rounded-xl bg-gradient-to-br from-purple-500 to-pink-500 hover:from-purple-600 hover:to-pink-600 text-white transition-all duration-300 shadow-lg hover:shadow-xl hover:scale-105 group ${
                        isCompact ? "p-1.5 sm:p-2" : "p-2 sm:p-2.5"
                      }`}
                      title="Quick Actions (⌘Q)"
                    >
                      <svg
                        className={`group-hover:rotate-90 transition-transform duration-300 ${
                          isCompact
                            ? "w-4 h-4 sm:w-4 sm:h-4"
                            : "w-4 h-4 sm:w-5 sm:h-5"
                        }`}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M13 10V3L4 14h7v7l9-11h-7z"
                        />
                      </svg>
                    </button>
                    {showQuickActions && (
                      <QuickActionsPanel onClose={onToggleQuickActions} />
                    )}
                  </div>

                  {/* Notifications */}
                  <div className="relative">
                    <button
                      onClick={onToggleNotifications}
                      className={`relative rounded-lg sm:rounded-xl bg-white border-2 border-gray-200 hover:border-indigo-400 hover:bg-gradient-to-br hover:from-indigo-50 hover:to-purple-50 transition-all duration-300 shadow-md hover:shadow-xl hover:scale-105 group ${
                        isCompact ? "p-1.5 sm:p-2" : "p-2 sm:p-2.5"
                      }`}
                      title="Notifications (⌘N)"
                    >
                      <svg
                        className={`text-gray-600 group-hover:text-indigo-600 transition-all duration-300 group-hover:rotate-12 ${
                          isCompact
                            ? "w-4 h-4 sm:w-4 sm:h-4"
                            : "w-4 h-4 sm:w-5 sm:h-5"
                        }`}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9"
                        />
                      </svg>
                      {notificationCount > 0 && (
                        <span className="absolute -top-1 -right-1 min-w-[20px] h-5 bg-gradient-to-r from-red-500 to-pink-500 rounded-full ring-2 ring-white flex items-center justify-center px-1.5 animate-pulse">
                          <span className="text-white text-xs font-bold">
                            {notificationCount}
                          </span>
                        </span>
                      )}
                    </button>
                    {showNotifications && (
                      <NotificationsPanel
                        count={notificationCount}
                        onClose={onToggleNotifications}
                      />
                    )}
                  </div>

                  {/* User profile */}
                  <div className="relative">
                    <button
                      onClick={onToggleUserMenu}
                      className={`rounded-lg sm:rounded-xl bg-gradient-to-br from-indigo-600 via-purple-600 to-pink-600 text-white hover:from-indigo-700 hover:via-purple-700 hover:to-pink-700 transition-all duration-300 shadow-lg hover:shadow-2xl hover:scale-105 flex items-center gap-1.5 sm:gap-2 md:gap-2.5 group ${
                        isCompact
                          ? "px-2 py-1.5 sm:px-3 sm:py-2"
                          : "px-2.5 py-2 sm:px-4 sm:py-2.5"
                      }`}
                    >
                      <div className="w-6 h-6 sm:w-7 sm:h-7 rounded-full bg-white/20 backdrop-blur flex items-center justify-center font-bold text-xs sm:text-sm ring-2 ring-white/30 group-hover:ring-white/50 transition-all">
                        A
                      </div>
                      <span className="hidden sm:inline text-xs sm:text-sm font-semibold">
                        Admin
                      </span>
                      <svg
                        className="w-3.5 h-3.5 sm:w-4 sm:h-4 group-hover:rotate-180 transition-transform duration-300"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M5.293 7.293a1 1 0 011.414 0L10 10.586l3.293-3.293a1 1 0 111.414 1.414l-4 4a1 1 0 01-1.414 0l-4-4a1 1 0 010-1.414z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </button>
                    {showUserMenu && (
                      <UserMenuPanel
                        onClose={onToggleUserMenu}
                        extra={userMenuExtra}
                      />
                    )}
                  </div>
                </div>
              </div>

              {/* Search bar + quick stats */}
              <div className="grid gap-3 sm:gap-4 lg:grid-cols-[1fr_auto] items-center">
                {/* Search */}
                <div className="relative group">
                  <div className="absolute -inset-1 bg-gradient-to-r from-indigo-500 via-purple-500 to-pink-500 rounded-2xl opacity-0 group-hover:opacity-30 blur-lg transition-all duration-500" />
                  <div className="relative flex items-center">
                    <div className="absolute left-3 sm:left-4 pointer-events-none">
                      <svg
                        className={`text-gray-400 group-hover:text-indigo-500 transition-colors duration-200 ${
                          isCompact ? "w-4 h-4" : "w-4 h-4 sm:w-5 sm:h-5"
                        }`}
                        fill="none"
                        viewBox="0 0 24 24"
                        stroke="currentColor"
                        strokeWidth="2"
                      >
                        <path
                          strokeLinecap="round"
                          strokeLinejoin="round"
                          d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z"
                        />
                      </svg>
                    </div>
                    <input
                      ref={searchInputRef}
                      type="text"
                      value={searchTerm}
                      onChange={handleSearchChange}
                      placeholder="Search products..."
                      className={`w-full rounded-xl sm:rounded-2xl border-2 border-gray-200 bg-white text-gray-900 placeholder:text-gray-400 focus:outline-none focus:ring-4 focus:ring-indigo-500/20 focus:border-indigo-500 shadow-lg hover:shadow-xl transition-all duration-300 ${
                        isCompact
                          ? "pl-10 pr-10 sm:pl-11 sm:pr-24 py-2.5 sm:py-3 text-sm"
                          : "pl-10 pr-10 sm:pl-12 sm:pr-28 py-3 sm:py-3.5 text-sm sm:text-base"
                      }`}
                      aria-label="Search products"
                    />
                    <div className="absolute inset-y-0 right-3 flex items-center gap-2">
                      {searchTerm && (
                        <button
                          onClick={onClearSearch}
                          className="search-clear-btn text-gray-400 hover:text-red-500 transition-all duration-200 p-1.5 hover:bg-red-50 rounded-lg group/clear"
                          aria-label="Clear search"
                        >
                          <svg
                            className="w-4 h-4 group-hover/clear:rotate-90 transition-transform"
                            fill="currentColor"
                            viewBox="0 0 20 20"
                          >
                            <path
                              fillRule="evenodd"
                              d="M10 18a8 8 0 100-16 8 8 0 000 16zM8.707 7.293a1 1 0 00-1.414 1.414L8.586 10l-1.293 1.293a1 1 0 101.414 1.414L10 11.414l1.293 1.293a1 1 0 001.414-1.414L11.414 10l1.293-1.293a1 1 0 00-1.414-1.414L10 8.586 8.707 7.293z"
                              clipRule="evenodd"
                            />
                          </svg>
                        </button>
                      )}
                      {isSearching ? (
                        <div className="flex items-center gap-1.5 px-2.5 py-1.5 bg-indigo-50 rounded-lg">
                          <svg
                            className="animate-spin h-4 w-4 text-indigo-600"
                            fill="none"
                            viewBox="0 0 24 24"
                          >
                            <circle
                              className="opacity-25"
                              cx="12"
                              cy="12"
                              r="10"
                              stroke="currentColor"
                              strokeWidth="4"
                            />
                            <path
                              className="opacity-75"
                              fill="currentColor"
                              d="M4 12a8 8 0 018-8V2a10 10 0 00-9.95 9.05L4 12z"
                            />
                          </svg>
                        </div>
                      ) : (
                        <kbd className="hidden md:inline-flex items-center gap-1 px-2.5 py-1.5 bg-gradient-to-br from-gray-100 to-gray-200 border border-gray-300 rounded-lg text-xs font-semibold text-gray-700 shadow-sm hover:shadow transition-all duration-200 hover:scale-105">
                          <span className="text-gray-500">⌘</span>K
                        </kbd>
                      )}
                    </div>
                  </div>
                </div>

                {/* Quick stats */}
                <div className="flex items-center gap-2 sm:gap-3">
                  {/* Products */}
                  <div className="stat-card-hover flex items-center gap-2 sm:gap-3 bg-gradient-to-br from-indigo-50 via-purple-50 to-pink-50 border-2 border-indigo-200/50 hover:border-indigo-300 rounded-xl sm:rounded-2xl px-3 sm:px-4 py-2.5 sm:py-3 shadow-md hover:shadow-xl group cursor-pointer transition-all duration-300">
                    <div className="icon-bounce flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-gradient-to-br from-indigo-500 to-purple-600 shadow-lg group-hover:shadow-indigo-300 group-hover:scale-110 transition-all duration-300">
                      <svg
                        className="w-4 h-4 sm:w-5 sm:h-5 text-white"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 000-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
                      </svg>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-[9px] sm:text-[10px] font-semibold text-gray-500 uppercase tracking-wider">
                        Products
                      </span>
                      <span className="stat-number text-base sm:text-lg md:text-xl font-extrabold bg-gradient-to-r from-indigo-600 via-purple-600 to-pink-600 bg-clip-text text-transparent">
                        {totalProducts.toLocaleString()}
                      </span>
                    </div>
                  </div>

                  {/* Categories */}
                  <div className="stat-card-hover hidden sm:flex items-center gap-2 md:gap-3 bg-gradient-to-br from-pink-50 via-rose-50 to-orange-50 border-2 border-pink-200/50 hover:border-pink-300 rounded-xl sm:rounded-2xl px-3 sm:px-4 py-2.5 sm:py-3 shadow-md hover:shadow-xl group cursor-pointer transition-all duration-300">
                    <div className="icon-bounce flex items-center justify-center w-8 h-8 sm:w-10 sm:h-10 rounded-lg sm:rounded-xl bg-gradient-to-br from-pink-500 to-orange-500 shadow-lg group-hover:shadow-pink-300 group-hover:scale-110 transition-all duration-300">
                      <svg
                        className="w-4 h-4 sm:w-5 sm:h-5 text-white"
                        fill="currentColor"
                        viewBox="0 0 20 20"
                      >
                        <path
                          fillRule="evenodd"
                          d="M2 5a2 2 0 012-2h12a2 2 0 012 2v10a2 2 0 01-2 2H4a2 2 0 01-2-2V5zm3.293 1.293a1 1 0 011.414 0l3 3a1 1 0 010 1.414l-3 3a1 1 0 01-1.414-1.414L7.586 10 5.293 7.707a1 1 0 010-1.414zM11 12a1 1 0 100 2h3a1 1 0 100-2h-3z"
                          clipRule="evenodd"
                        />
                      </svg>
                    </div>
                    <div className="flex flex-col">
                      <span className="text-[9px] sm:text-[10px] font-semibold text-gray-500 uppercase tracking-wider">
                        Categories
                      </span>
                      <span className="stat-number text-base sm:text-lg md:text-xl font-extrabold bg-gradient-to-r from-pink-600 via-rose-600 to-orange-600 bg-clip-text text-transparent">
                        {categories.length - 1}
                      </span>
                    </div>
                  </div>

                  {/* Live status */}
                  <div className="hidden md:flex items-center gap-2 bg-gradient-to-br from-green-50 to-emerald-50 border-2 border-green-200/50 hover:border-green-300 rounded-xl lg:rounded-2xl px-3 lg:px-4 py-2.5 lg:py-3 shadow-md hover:shadow-xl cursor-pointer transition-all duration-300 group">
                    <span className="relative flex h-3 w-3">
                      <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-green-400 opacity-75" />
                      <span className="relative inline-flex rounded-full h-3 w-3 bg-green-500 ring-2 ring-green-200" />
                    </span>
                    <div className="flex flex-col">
                      <span className="text-[9px] sm:text-[10px] font-semibold text-gray-500 uppercase tracking-wider">
                        Status
                      </span>
                      <span className="text-xs sm:text-sm font-bold text-green-700">
                        Live
                      </span>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </header>
    </>
  );
}
