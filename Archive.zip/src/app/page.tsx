'use client';

import { useEffect, useRef, useState } from 'react';
import { Product, ProductListResponse } from '@/types/product';
import { CompanyProfile, DEFAULT_COMPANY_PROFILE } from '@/types/company';
import Image from 'next/image';
import Link from 'next/link';
import CatalogHeader, { type CatalogHeaderConfig } from '@/components/CatalogHeader';
import { useScrollBehavior } from '@/hooks/useScrollBehavior';

export const dynamic = 'force-dynamic';

interface CachedProductsData {
  products: Product[];
  totalPages: number;
  totalProducts: number;
  categories: string[];
  company: CompanyProfile;
  timestamp: number;
}

export default function Catalog() {
  const [products, setProducts] = useState<Product[]>([]);
  const [loading, setLoading] = useState(true);
  const [isInitialLoad, setIsInitialLoad] = useState(true);
  const [page, setPage] = useState(1);
  const [totalPages, setTotalPages] = useState(1);
  const [totalProducts, setTotalProducts] = useState(0);
  const [searchTerm, setSearchTerm] = useState('');
  const [debouncedSearch, setDebouncedSearch] = useState('');
  const [categories, setCategories] = useState<string[]>(['all']);
  const [selectedCategory, setSelectedCategory] = useState('all');
  const [company, setCompany] = useState<CompanyProfile>(DEFAULT_COMPANY_PROFILE);
  const [isSearching, setIsSearching] = useState(false);
  const [hasMore, setHasMore] = useState(true);
  const [isFetchingMore, setIsFetchingMore] = useState(false);

  // Dropdown toggles
  const [showNotifications, setShowNotifications] = useState(false);
  const [showUserMenu, setShowUserMenu] = useState(false);
  const [showQuickActions, setShowQuickActions] = useState(false);

  // System monitoring state
  const [apiResponseTime, setApiResponseTime] = useState(0);
  const [activeUsers, setActiveUsers] = useState(0);
  const [systemHealth, setSystemHealth] = useState<'healthy' | 'warning' | 'critical'>('healthy');

  const productCacheRef = useRef<Map<string, CachedProductsData>>(new Map());
  const loadMoreRef = useRef<HTMLDivElement | null>(null);
  const limit = 24;

  // Scroll behavior
  const { isScrolled, isHeaderVisible, isCompact, scrollProgress, showHeader } = useScrollBehavior();

  /* ── merge helper ────────── */
  const mergeProducts = (existing: Product[], incoming: Product[]) => {
    const ids = new Set(existing.map((p) => p.id));
    return [...existing, ...incoming.filter((p) => !ids.has(p.id))];
  };

  /* ── system monitoring ───── */
  useEffect(() => {
    const interval = setInterval(() => {
      const rt = Math.floor(Math.random() * 150) + 50;
      setApiResponseTime(rt);
      setActiveUsers(Math.floor(Math.random() * 400) + 100);
      setSystemHealth(rt < 100 ? 'healthy' : rt < 150 ? 'warning' : 'critical');
    }, 5000);
    return () => clearInterval(interval);
  }, []);

  /* ── keyboard shortcuts ──── */
  useEffect(() => {
    const handler = (e: KeyboardEvent) => {
      if ((e.metaKey || e.ctrlKey) && e.key === 'n') {
        e.preventDefault();
        setShowNotifications((v) => !v);
      }
      if ((e.metaKey || e.ctrlKey) && e.key === 'q') {
        e.preventDefault();
        setShowQuickActions((v) => !v);
      }
    };
    window.addEventListener('keydown', handler);
    return () => window.removeEventListener('keydown', handler);
  }, []);

  /* ── debounce search ─────── */
  useEffect(() => {
    setIsSearching(true);
    const t = setTimeout(() => {
      setDebouncedSearch(searchTerm.trim());
      setPage(1);
      setIsSearching(false);
    }, 300);
    return () => { clearTimeout(t); setIsSearching(false); };
  }, [searchTerm]);

  /* ── fetch products ──────── */
  useEffect(() => {
    const fetchProducts = async () => {
      if (page === 1) setLoading(true);

      try {
        const params = new URLSearchParams({ page: page.toString(), limit: limit.toString() });
        if (debouncedSearch) params.set('search', debouncedSearch);
        if (selectedCategory !== 'all') params.set('category', selectedCategory);

        const cacheKey = params.toString();
        const cached = productCacheRef.current.get(cacheKey);
        if (cached && Date.now() - cached.timestamp < 60_000) {
          if (page === 1) setProducts(cached.products);
          else setProducts((prev) => mergeProducts(prev, cached.products));
          setTotalPages(cached.totalPages);
          setTotalProducts(cached.totalProducts);
          setCategories(['all', ...cached.categories]);
          setCompany({ ...DEFAULT_COMPANY_PROFILE, ...cached.company });
          setHasMore(page < cached.totalPages);
          setLoading(false);
          setIsInitialLoad(false);
          setIsFetchingMore(false);
          return;
        }

        const res = await fetch(`/api/products?${params}`);
        const data: ProductListResponse = await res.json();

        if (res.ok && data.products) {
          if (data.company) setCompany({ ...DEFAULT_COMPANY_PROFILE, ...data.company });
          const incoming = data.products;
          setProducts((prev) => (page === 1 ? incoming : mergeProducts(prev, incoming)));
          setTotalPages(data.totalPages || 1);
          setTotalProducts(data.total || 0);
          setHasMore(page < (data.totalPages || 1));
          if (Array.isArray(data.categories) && data.categories.length > 0) {
            setCategories(['all', ...data.categories]);
          }

          productCacheRef.current.set(cacheKey, {
            products: incoming,
            totalPages: data.totalPages || 1,
            totalProducts: data.total || 0,
            categories: Array.isArray(data.categories) ? data.categories : [],
            company: { ...DEFAULT_COMPANY_PROFILE, ...data.company },
            timestamp: Date.now(),
          });
        } else {
          setProducts([]);
          setTotalPages(1);
          setTotalProducts(0);
          setHasMore(false);
        }
      } catch (err) {
        console.error('Fetch error:', err);
        setProducts([]);
        setTotalPages(1);
        setTotalProducts(0);
        setHasMore(false);
      } finally {
        setLoading(false);
        setIsInitialLoad(false);
        setIsFetchingMore(false);
      }
    };

    fetchProducts();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [page, debouncedSearch, selectedCategory]);

  /* ── infinite scroll ─────── */
  useEffect(() => {
    if (!loadMoreRef.current) return;
    const observer = new IntersectionObserver(
      (entries) => {
        if (entries[0].isIntersecting && hasMore && !loading && !isFetchingMore) {
          setPage((p) => p + 1);
        }
      },
      { rootMargin: '200px' }
    );
    const el = loadMoreRef.current;
    observer.observe(el);
    return () => observer.unobserve(el);
  }, [hasMore, loading, isFetchingMore]);

  const handleSearchChange = (value: string) => setSearchTerm(value);
  const handleClearSearch = () => setSearchTerm('');

  const handleCategorySelect = (category: string) => {
    setSelectedCategory(category);
    setPage(1);
    setLoading(true);
    setHasMore(true);
    productCacheRef.current.clear();
  };

  const handlePageChange = (newPage: number) => {
    if (newPage >= 1 && newPage <= totalPages && newPage !== page) {
      setPage(newPage);
      window.scrollTo({ top: 0, behavior: 'smooth' });
    }
  };

  /* ── build header config ─── */
  const headerConfig: CatalogHeaderConfig = {
    companyName: company.name,
    companyTagline: company.tagline,
    totalProducts,
    categories,
    activeCategory: selectedCategory,
    searchTerm,
    isSearching,
    isScrolled,
    isHeaderVisible,
    isCompact,
    scrollProgress,
    systemHealth,
    apiResponseTime,
    activeUsers,
    notificationCount: 3,
    showNotifications,
    showUserMenu,
    showQuickActions,
  };

  /* ── loading screen ──────── */
  if (loading && isInitialLoad) {
    return (
      <div className="flex flex-col justify-center items-center h-screen bg-gray-50">
        <div className="relative">
          <div className="w-16 h-16 border-4 border-gray-200 border-t-indigo-600 rounded-full animate-spin" />
        </div>
        <p className="mt-4 text-lg font-medium text-gray-700">Loading E-Cat...</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <CatalogHeader
        config={headerConfig}
        onSearchChange={handleSearchChange}
        onClearSearch={handleClearSearch}
        onCategorySelect={handleCategorySelect}
        onToggleNotifications={() => setShowNotifications((v) => !v)}
        onToggleUserMenu={() => setShowUserMenu((v) => !v)}
        onToggleQuickActions={() => setShowQuickActions((v) => !v)}
        onShowHeader={showHeader}
      />

      {/* Show Header Button */}
      {!isHeaderVisible && isScrolled && (
        <button
          onClick={showHeader}
          className="fixed top-0 left-1/2 -translate-x-1/2 z-40 bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-4 py-2 rounded-b-xl shadow-2xl hover:shadow-indigo-500/50 transition-all duration-300 hover:scale-105 flex items-center gap-2 animate-slideDown"
          aria-label="Show header"
        >
          <svg className="w-4 h-4" fill="none" viewBox="0 0 24 24" strokeWidth="2" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" d="M19 9l-7 7-7-7" />
          </svg>
          <span className="text-sm font-medium">Show Header</span>
        </button>
      )}

      {/* Category Filter */}
      <div
        className={`sticky z-30 bg-white/95 backdrop-blur-sm border-b border-gray-200 shadow-sm transition-all duration-300 ${
          isHeaderVisible
            ? isCompact
              ? 'top-[70px]'
              : 'top-[73px]'
            : 'top-0'
        }`}
      >
        <div className="px-4 md:px-6 lg:px-8 py-4">
          <div className="flex items-center gap-3 overflow-x-auto scrollbar-hide">
            <span className="text-sm font-medium text-gray-700 whitespace-nowrap">Categories:</span>
            <div className="flex gap-2">
              {categories.map((cat) => (
                <button
                  key={cat}
                  onClick={() => handleCategorySelect(cat)}
                  className={`px-4 py-2 rounded-full text-sm font-medium whitespace-nowrap transition-all duration-200 ${
                    selectedCategory === cat
                      ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30 scale-105'
                      : 'bg-gray-100 text-gray-700 hover:bg-gray-200 hover:scale-105'
                  }`}
                >
                  {cat === 'all' ? '🏠 All Products' : `📦 ${cat.charAt(0).toUpperCase() + cat.slice(1)}`}
                </button>
              ))}
            </div>
          </div>
        </div>
      </div>

      {/* Stats Bar */}
      {!loading && products.length > 0 && (
        <div className="px-4 md:px-6 lg:px-8 py-4 bg-gradient-to-r from-indigo-50 to-purple-50">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="flex items-center gap-6">
              <div className="flex items-center gap-2">
                <div className="w-2 h-2 bg-green-500 rounded-full animate-pulse" />
                <span className="text-sm text-gray-700">
                  Showing <span className="font-bold text-indigo-600">{products.length}</span> of{' '}
                  <span className="font-bold text-indigo-600">{totalProducts}</span> products
                </span>
              </div>
              {debouncedSearch && (
                <div className="flex items-center gap-2 px-3 py-1 bg-white rounded-full shadow-sm">
                  <svg className="w-4 h-4 text-indigo-600" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-4.35-4.35m0 0A7.5 7.5 0 1016.65 16.65z" />
                  </svg>
                  <span className="text-xs text-gray-600">Search: &ldquo;{debouncedSearch}&rdquo;</span>
                </div>
              )}
            </div>
            <div className="text-xs text-gray-500">Page {page} of {totalPages}</div>
          </div>
        </div>
      )}

      {/* Main Content */}
      <main className="px-4 md:px-6 lg:px-8 py-8">
        {renderProducts()}
      </main>

      {/* Scroll to Top */}
      <button
        onClick={() => window.scrollTo({ top: 0, behavior: 'smooth' })}
        className={`fixed bottom-8 right-8 z-40 p-4 rounded-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-2xl shadow-indigo-500/50 hover:shadow-indigo-500/70 hover:scale-110 transition-all duration-300 group ${
          isScrolled ? 'translate-y-0 opacity-100' : 'translate-y-20 opacity-0 pointer-events-none'
        }`}
        aria-label="Scroll to top"
      >
        <svg className="w-6 h-6 group-hover:-translate-y-1 transition-transform duration-300" fill="none" stroke="currentColor" strokeWidth="3" viewBox="0 0 24 24">
          <path strokeLinecap="round" strokeLinejoin="round" d="M5 10l7-7m0 0l7 7m-7-7v18" />
        </svg>
        <span className="absolute -top-1 -right-1 w-3 h-3 bg-green-500 rounded-full animate-pulse ring-2 ring-white" />
      </button>
    </div>
  );

  /* ================================================================ */
  /*  RENDER PRODUCTS                                                 */
  /* ================================================================ */
  function renderProducts() {
    // Loading skeleton (incremental)
    if (loading && !isInitialLoad) {
      return (
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-4" role="status" aria-live="polite">
          {[...Array(limit)].map((_, i) => (
            <div key={i} className="bg-white rounded-lg shadow overflow-hidden border border-gray-200 animate-pulse">
              <div className="w-full h-48 bg-gray-200" />
              <div className="p-4 space-y-2">
                <div className="h-4 bg-gray-200 rounded w-3/4" />
                <div className="h-3 bg-gray-200 rounded w-1/2" />
                <div className="h-8 bg-gray-200 rounded w-full mt-3" />
              </div>
            </div>
          ))}
        </div>
      );
    }

    // Empty state
    if (!loading && products.length === 0) {
      return (
        <div className="max-w-md mx-auto text-center py-16">
          <div className="w-20 h-20 mx-auto mb-4 bg-gray-100 rounded-full flex items-center justify-center">
            <svg className="w-10 h-10 text-gray-400" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
              <path strokeLinecap="round" strokeLinejoin="round" d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-900 mb-2">No Products Found</h2>
          <p className="text-gray-600 mb-6">We couldn't find any products matching your criteria.</p>
          {(debouncedSearch || selectedCategory !== 'all') && (
            <button
              onClick={() => { setSearchTerm(''); handleCategorySelect('all'); }}
              className="inline-flex items-center gap-2 rounded-lg bg-indigo-600 px-6 py-3 text-white font-medium hover:bg-indigo-700 transition-colors"
            >
              <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                <path fillRule="evenodd" d="M4 2a1 1 0 011 1v2.101a7.002 7.002 0 0111.601 2.566 1 1 0 11-1.885.666A5.002 5.002 0 005.999 7H9a1 1 0 010 2H4a1 1 0 01-1-1V3a1 1 0 011-1zm.008 9.057a1 1 0 011.276.61A5.002 5.002 0 0014.001 13H11a1 1 0 110-2h5a1 1 0 011 1v5a1 1 0 11-2 0v-2.101a7.002 7.002 0 01-11.601-2.566 1 1 0 01.61-1.276z" clipRule="evenodd" />
              </svg>
              Reset Filters
            </button>
          )}
        </div>
      );
    }

    return (
      <div className="space-y-8">
        <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 xl:grid-cols-6 2xl:grid-cols-7 gap-4">
          {products.map((product) => (
            <div
              key={product.id}
              className="group bg-white rounded-lg shadow hover:shadow-lg transition-all duration-300 overflow-hidden border border-gray-200 hover:border-indigo-300"
            >
              <div className="relative overflow-hidden bg-gray-50">
                <Image
                  src={product.imageUrl}
                  alt={product.name}
                  width={300}
                  height={300}
                  className="w-full h-48 object-cover transition-transform duration-300 group-hover:scale-105"
                  loading="lazy"
                  sizes="(max-width: 640px) 50vw, (max-width: 1024px) 33vw, 20vw"
                />
                {product.inventory === 0 ? (
                  <div className="absolute top-2 right-2 bg-red-500 text-white px-2 py-1 rounded text-xs font-medium shadow">Out of Stock</div>
                ) : product.inventory <= 5 ? (
                  <div className="absolute top-2 right-2 bg-orange-500 text-white px-2 py-1 rounded text-xs font-medium shadow">Low Stock</div>
                ) : (
                  <div className="absolute top-2 right-2 bg-green-500 text-white px-2 py-1 rounded text-xs font-medium shadow">In Stock</div>
                )}
                <div className="absolute top-2 left-2 bg-white/95 backdrop-blur-sm text-gray-700 px-2 py-1 rounded text-xs font-medium shadow-sm">
                  {product.category}
                </div>
              </div>
              <div className="p-4">
                <h2 className="text-sm font-semibold text-gray-900 mb-1 line-clamp-2 group-hover:text-indigo-600 transition-colors">
                  {product.name}
                </h2>
                <p className="text-xs text-gray-500 mb-3 line-clamp-1">{product.description}</p>
                <div className="flex justify-between items-center mb-3">
                  {company.showPrices && (
                    <p className="text-lg font-bold text-indigo-600">${(product.price || 0).toFixed(2)}</p>
                  )}
                  {product.inventory > 0 && <p className="text-xs text-gray-600">{product.inventory} units</p>}
                </div>
                <Link
                  href={`/product/${product.id}`}
                  className="w-full inline-flex items-center justify-center gap-1 bg-indigo-600 hover:bg-indigo-700 text-white px-4 py-2 rounded-lg transition-colors text-sm font-medium"
                >
                  View Details
                  <svg className="w-3 h-3" fill="none" stroke="currentColor" strokeWidth="2" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M13 7l5 5m0 0l-5 5m5-5H6" />
                  </svg>
                </Link>
              </div>
            </div>
          ))}
        </div>

        {/* Infinite scroll trigger */}
        {!hasMore && totalPages <= 1 ? null : (
          <div className="flex justify-center mt-6">
            <div ref={loadMoreRef} className="flex items-center gap-2 rounded-full bg-white px-4 py-2 shadow-sm border border-gray-200">
              {isFetchingMore && (
                <svg className="h-4 w-4 animate-spin text-indigo-600" viewBox="0 0 24 24" fill="none">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4" />
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V2a10 10 0 00-9.95 9.05L4 12z" />
                </svg>
              )}
              <span className="text-xs font-medium text-gray-600">
                {hasMore ? 'Loading more products…' : 'You have reached the end'}
              </span>
            </div>
          </div>
        )}

        {/* Pagination */}
        {totalPages > 1 && (
          <div className="mt-12 mb-8">
            <div className="flex flex-col items-center gap-4">
              <div className="flex items-center gap-2 bg-white rounded-2xl shadow-lg p-2 border border-gray-200">
                <button
                  onClick={() => handlePageChange(page - 1)}
                  disabled={page === 1}
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-gray-100 to-gray-200 text-gray-700 text-sm font-semibold hover:from-gray-200 hover:to-gray-300 disabled:opacity-40 disabled:cursor-not-allowed transition-all duration-200 hover:scale-105 disabled:hover:scale-100"
                >
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M15 19l-7-7 7-7" />
                  </svg>
                  <span className="hidden sm:inline">Previous</span>
                </button>

                <div className="flex items-center gap-1 px-2">
                  {Array.from({ length: totalPages }, (_, i) => i + 1).map((p) => {
                    const showPage = p === 1 || p === totalPages || (p >= page - 1 && p <= page + 1);
                    const showEllipsis = (p === page - 2 && page > 3) || (p === page + 2 && page < totalPages - 2);
                    if (showEllipsis) return <span key={p} className="px-3 text-gray-400 font-bold">⋯</span>;
                    if (!showPage) return null;
                    return (
                      <button
                        key={p}
                        onClick={() => handlePageChange(p)}
                        className={`min-w-[44px] h-11 px-4 rounded-xl text-sm font-bold transition-all duration-200 ${
                          p === page
                            ? 'bg-gradient-to-r from-indigo-600 to-purple-600 text-white shadow-lg shadow-indigo-500/30 scale-110'
                            : 'bg-gray-50 text-gray-700 hover:bg-gray-100 hover:scale-105'
                        }`}
                      >
                        {p}
                      </button>
                    );
                  })}
                </div>

                <button
                  onClick={() => handlePageChange(page + 1)}
                  disabled={page === totalPages}
                  className="inline-flex items-center gap-2 px-5 py-3 rounded-xl bg-gradient-to-r from-gray-100 to-gray-200 text-gray-700 text-sm font-semibold hover:from-gray-200 hover:to-gray-300 disabled:opacity-40 disabled:cursor-not-allowed transition-all duration-200 hover:scale-105 disabled:hover:scale-100"
                >
                  <span className="hidden sm:inline">Next</span>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" strokeWidth="2.5" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" d="M9 5l7 7-7 7" />
                  </svg>
                </button>
              </div>
              <div className="text-sm text-gray-600 bg-white px-6 py-2 rounded-full shadow-sm border border-gray-200">
                Page <span className="font-bold text-indigo-600">{page}</span> of <span className="font-bold text-indigo-600">{totalPages}</span>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }
}
